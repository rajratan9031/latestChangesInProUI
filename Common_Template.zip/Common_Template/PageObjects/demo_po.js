(function() {
    'use strict';

    var currentPage = 'pageObjPage';


    var PageObjPage = function() {

        return {

            get: function () {
                return browser.get(browser.params.login.baseUrl);
                browser.waitForAngular();
            },

            getNameField: function () {
                return element(by.name('username'));
            },
            setName: function (username) {
                return this.getNameField().sendKeys(username);
            },
            clearName: function () {
                return this.getNameField().clear();
            },
			
            getPasswordField: function () {
                return element(by.name('password'));
            },
            setPassword: function (password) {
                return this.getPasswordField().sendKeys(password);
            },
            clearPassword: function () {
                return this.getPasswordField().clear();
            },


            getLoginBtn: function () {
                return element(by.css('input#submitFrm'));
            },
            clickLogin: function () {
  //              input.sendKeys(protractor.Key.ENTER);
                return this.getPasswordField().sendKeys(protractor.Key.ENTER);
 //               return this.getPredixLoginBtn().click();
            },

           /* Actual code   */
		   
            waitForCustomerLoginBtn: function () {
                //browser.waitForAngular();
                browser.sleep(15000);
                return TestHelper.isElementPresent(currentPage, 'customerLoginBtn');
            },
			
			customerLoginBtn: function() {
             browser.waitForAngular();
             browser.driver.sleep(15000);
               return cem.findElement(currentPage, 'customerLoginBtn').click();
              },
			  
			  yourNameDropdown: function() {
             browser.waitForAngular();
             browser.driver.sleep(11000);
               return cem.findElement(currentPage, 'yourNameDropdown').click();
              },


            yourNameSelection: function () {
              browser.waitForAngular();
                browser.driver.sleep(1000);
                return element(by.xpath("//*[@class='btn btn-primary btn-lg'][text()='Customer Login']")).click()
				//cem.findElement(currentPage, 'yourNameSelection').click();
            },
			
			loginBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'loginBtn').click();
            },
			transactionBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage, 'transactionBtn').click();
            },






        }

	};

    module.exports = new PageObjPage();

}());
