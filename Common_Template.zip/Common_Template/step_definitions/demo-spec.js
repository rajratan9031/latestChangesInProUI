var currentPage = 'pageObjPage';
module.exports = function() {
this.Given(/^I go to url$/, function (callback) {
        browser.ignoreSynchronization = true;
         pageObjPage.get().then(function(){
			browser.sleep(8000);
            //analysisPage.getUserName().then(function () {
                callback();
            //});
        });

    });
	
		this.Then(/^I can able to click on Customer login button$/, function() {
		 browser.ignoreSynchronization = true;
         pageObjPage.customerLoginBtn().then(function() {
		//element(by.xpath("//*[@class='btn btn-primary btn-lg'][text()='Customer Login']")).click().then(function () {
            browser.sleep(8000);
                 //callback();
                });
        // });
});

this.Given(/^I can select your Name dropdown$/, function () {
        pageObjPage.yourNameDropdown().then(function () {
			browser.sleep(1000);
            //callback();
        });
    });

    this.Given(/^I can select your Name$/, function () {
        pageObjPage.yourNameSelection().then(function () {
			browser.sleep(1000);
            //callback();
        });
    });
	

};
