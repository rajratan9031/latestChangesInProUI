/**
 * Created by 212556710 on 5/9/16.
 */
exports.config = {

	// ---- While testing locally
	sauceUser: null,
	sauceKey: null,
	sauceSeleniumAddress: null,

	directConnect: false,
	firefoxPath: null,
	//seleniumAddress: 'http://127.0.0.1:4444/wd/hub',

	// ---------------------------------------------------------------------------
	// ----- What tests to run ---------------------------------------------------
	// ---------------------------------------------------------------------------

	// Spec patterns are relative to the location of this config.
	specs: [],

	// Patterns to exclude.
	exclude: [],

	// Organize spec files into suites. To run specific suite, --suite=<name of suite>
	 suites: {

        demoSuite:[

            "../Features/demoProject.feature",
        ],
    },

	// Hooks running in the background
	plugins: [{
		path: '../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
	}],

	// Browser options
    capabilities: {
        browserName: 'chrome',
        /*proxy:{
            proxyType:'manual',
            httpProxy: 'sjc1intproxy02.crd.ge.com:8080',
            sslProxy: 'sjc1intproxy02.crd.ge.com:8080',
        },*/
        count: 1,
        shardTestFiles: false,
        maxInstances: 1,
        'chromeOptions': {
            args: ['--no-sandbox', '--test-type=browser'],
            prefs: {
                'download': {
	//maxSessions: 2,
	//defaultTimeoutInterval: 90000,
    //allScriptsTimeout: 900000,
    //getPageTimeout: 900000,
                    //'prompt_for_download': false,
                    //'directory_upgrade': true,
                    //'default_directory': 'C:/Users/radha_000/Desktop/ProUI_Space'

                    // 'download': {
                    //     'directory_upgrade': true,
                    //     'prompt_for_download': false,
                    //     //'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
                    //     //'default_directory': '/DownLoad/'
                    //     'default_directory': 'C:/Users/rmanchik/Documents/Automation/TestData/DownLoad/'
                    // }

                }
            }
        }
    },

	/*params: {
		env: 'dev'
	},*/

	maxSessions: -1,

	allScriptsTimeout: 900000,

	// How long to wait for a page to load.
	getPageTimeout: 900000,
	defaultTimeoutInterval: 900000,

	// Before launching the application
	beforeLaunch: function () {
	},

	// Application is launched but before it starts executing
	onPrepare: function () {

		// Create reports folder if it does not exist
		var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
		var mkdirp = require('mkdirp');
		var reportsPath = "./Reports/";

		mkdirp(reportsPath, function (err) {
			if (err) {
				console.error(err);
			} else {
			}
		});

		browser.manage().deleteAllCookies();
		browser.manage().timeouts().pageLoadTimeout(90000);
		browser.manage().timeouts().implicitlyWait(90000);
		browser.driver.manage().window().maximize();
		//browser.driver.manage().window().setSize(1280, 1440);

		chai = require('chai');
		expect = chai.expect;
		path = require('path');
		Cucumber = require('cucumber');
		fs = require('fs');

		// Initializing page object variables
		pageObjPage = require('../PageObjects/demo_po.js');

		// Initializing necessary utils from ProUI-Utils module
		TestHelper = require('ProUI-Utils').TestHelper;
		TestHelperPO = require('ProUI-Utils').TestHelperPO;
		ElementManager = require('ProUI-Utils').ElementManager;
		Logger = require('ProUI-Utils').Logger;
		cem = new ElementManager('../../../Common_Template/common-element-repo.json');
		TestHelper.setElementManager(cem);

	},

	// A callback function called once tests are finished
	onComplete: function () {

	},


	// A callback function called once tests are cleaning up
	onCleanUp: function (exitCode) {

	},

	// A callback function after tests are launched
	afterLaunch: function () {

	},

// Browser parameters for feature files.
	 params: {
        login: {
            //baseUrl:'http://www.angularjs.org',
			baseUrl: 'http://www.globalsqa.com/angularJs-protractor/BankingProject/#/login',

            "username": "radha.mrk@gmail.com",
            "password": "testing",


        }
    },

	resultJsonOutputFile: null,

	// If true, protractor will restart the browser between each test.
	// CAUTION: This will cause your tests to slow down drastically.
	restartBrowserBetweenTests: false,

	// Custom framework in this case cucumber
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	cucumberOpts: {

		// define your step definitions in this file
		require: [
			'../step_definitions/env.js',
			'./../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
			//'../step_definitions/*'
			'../step_definitions/demo-spec.js',
		],

		//format: 'pretty'
		 keepAlive: false 
	}
};

